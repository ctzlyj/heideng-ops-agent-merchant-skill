"""Merchant-isolated delivery and thin dispatch to mature business Skills."""
VERSION = "0.4.7"
SKILL_NAME = "heideng-ops-agent-merchant"
