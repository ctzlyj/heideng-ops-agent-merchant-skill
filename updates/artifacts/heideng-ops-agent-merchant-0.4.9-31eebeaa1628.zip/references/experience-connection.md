# 连接店铺与复用授权

## 适用问题与需要的事实

商家报店名/简称/venderId，需要找店、复用现有授权、首次授权或排障。先确认商家要操作的店；shopId 与 venderId 不能混用。多店匹配返回 ambiguous 时问具体哪一家，不选默认店。

需要本商家独立 CLI 和状态目录、成熟连接器返回的 Profile，以及实时 venderId/shopId/shopName。所有店铺模块可共享这次已核验身份；模块切换不是重新扫码理由。

## 判断与建议路径

- 通常先 `run connection -- ensure-shop --shop "目标店铺" --no-auth`。登记别名/多个Profile只用于定位，最终以实时 venderinfo 核验为准。
- 已有授权可用则直接复用；本地显示过期不代表不可用，官方可能自动刷新。网络/权限错误不能一律当授权失效；先按实际错误排障。
- 确实需新授权，沿用用户针对本店的明确许可，原 ensure-shop 去掉 --no-auth；商家本人在同一隔离浏览器页自行选择密码、短信或扫码，宿主衔接官方 OAuth。不要另建授权系统，不复制Cookie/Token。
- `awaiting_auth` 只有在原会话确实仍运行时才表示等待，不是授权失败；默认builtin由包内流程驱动，不交给宿主手拼OAuth。按原 jobId、当前 browser-action 操作并回报真实上下文/身份，返回 callback_unknown 时先核对同一Profile，不能再扫一轮制造重复任务。
- 网页后续任务需要真实商家持久 profileDir。用原连接器保存的 browserProfileDir，在同店匹配后交给 POP 原导入；不猜用户工作浏览器目录。

路径可由宿主已有浏览器工具完成。包装器没有某个宿主操作入口并不禁止宿主处理原 HostBrowser 动作；配置/报告必须是实际拥有的上下文，不能凭标签存在填 owned/isolation/身份。

## 工具与完成证据

- `scripts/merchant.py run connection -- ensure-shop|resolve|wait|verify|doctor ...`，由Agent补原命令实际参数。
- 真实 HostBrowser 契约：[原适配器](../mature/connection/app/browser_adapters.py)；可选私有输送：[browser_bridge](../mature/connection/scripts/browser_bridge.py)。
- 完成：实时正确店铺身份、可用专用Profile和官方凭据原管理结果。网页登录成功或本地连接命令启动不等于 ready。
- 用户未交办业务：完成连接后不自动发布、采集、改价或付费生成。

## 来源、例外和限制

整理自 jingmai-cli-linker 1.0.2 / 1c438fc；[原用法](../mature/connection/references/usage.md)、[浏览器会话](../mature/connection/references/browser-session.md)。原文个人目录/固定服务端口是源版本背景，商家路径/实际端口以本包环境为准，见 [环境](merchant-cli-environment.md)。
真实商家新授权与各宿主实机没有本次实测结论；这是环境证据限制，不是长期禁止未来授权。官方权限或宿主浏览器能力缺失时报告具体缺项，不借员工身份。


## 0.4.2 连接执行路径（本地适配，不替代真实验收）

- 首次连接由宿主先 `ensure-shop --no-auth`；已有ready直接结束，不启动连接服务。确需本店新授权时去掉no-auth，保留awaiting_auth的jobId/Profile。
- 本包提供 `scripts/host_connection_controller.py`。宿主在任务目录用准备好的runtime解释器运行它作为browser_bridge的controller argv，不再自己编写CDP服务、OAuth确认脚本或Profile登记补丁。`python scripts/merchant.py run --entry scripts/browser_bridge.py connection -- --controller '<该argv JSON>' --once --timeout 20`。普通observe没有回报时继续观察原任务；导航/确认未明时先核对，不能重复点击。
- 控制器只使用商家state/browser-profiles的持久目录和同contextId。登录页为passport.shop.jd.com/login/index.action；不替商家选择扫码/密码/短信，不复制Cookie。商家本人处理登录/风控；认证魔方明确去京东商城App完成安全验证，后台不继续发新授权。
- 同店普通重试不会返回旧failed job。需要原Profile/页面恢复时用ensure-shop --resume，它先核验已有结果；不擅自cancel，不把result_unknown改为未提交。连接服务用脱离CLI进程组方式启动，宿主结束单条命令不等于结束授权。
- OAuth确认只用于当前已许可范围；额外权限/费用/挑战交还本人。控制器只回报非敏感页面身份与context/profile元数据；最终ready仍以官方Profile实时venderinfo核店。
- 这是必要的WorkBuddy/宿主适配。真实京麦登录、账号风控、OAuth与各宿主进程回收仍需实际设备内测，不能把控制器本地测试称为真实商家授权通过。


## 单命令连接（替代0.4.2手工循环主路径）

新店已获用户明确授权后，宿主只调用 `ensure-shop --shop <目标> --timeout 600`，不传 `--no-open`。默认provider=builtin，由原BrowserAuthJob直接驱动包内HostConnectionController；宿主不再循环browser_bridge、拼controller argv或常驻临时控制器。老店`--no-auth` ready不会打开浏览器。

浏览器默认跟随本机Chrome/Edge设置，之后绑定同店context/profile/channel。登录页交给商家选择密码/短信/扫码，文本店名不是完整身份；只从已登录工作台读取可靠店铺信息，最终仍以官方venderinfo核店。遇到账号风控只提示本人操作，不重开任务。

0.4.2手工`browser_bridge`入口保留给需要自带HostBrowser的宿主，不是默认新店路径。页面驱动随动作释放，商家profile保留，不能反复打开新窗口。OAuth确认最多一次；超时只观察/核验，不重复点击。

## 0.4.5 现场反馈适配

- 新店默认仍是单命令 `ensure-shop`。工作台只有店名、没有 DOM venderId 时，店名匹配只用于进入官方 OAuth；最终 ready 仍须官方 Profile 实时返回匹配的店名与数字 venderId，不能用文本店名代替完整核店。
- 返回中的 `browserChannel` 是实际通道，`browserSelectionReason=system-default-https` 表示跟随系统默认浏览器，`reused-shop-session` 表示复用同店隔离会话。Edge/Chrome 不是串号依据；商家登录方式始终由本人选择。
- `/api/job` 丢失会明确返回 `job_lost`，同店再次 `ensure-shop` 默认恢复；已取消任务新建同店 worker，不假装原线程仍存活。多店会话目录和 Profile 不混用。
- 控制器 `--help` / `--describe-contract` 不需要商家状态目录。Key 的 Tk 回退页会输出不含 session/CSRF 的本机根地址；不得把带令牌的输入 URL、Key 或 Cookie 写入日志/回复。

## 0.4.6 授权进程生命周期（必须遵守）

- 新店默认只执行 `run connection -- ensure-shop --shop <目标> --timeout 600`。builtin 在**当前命令进程内**运行既有连接服务；登录和OAuth共用本次有界连接预算；`waiting_browser` 是内置控制器正在打开页面，不是让宿主接管。
- 不要在这条默认路径里另跑 `jdo-cli login --no-browser`、手工拼 OAuth URL、`Start-Process msedge/chrome`、用 `present_files` 展示链接，或让商家复制链接。上述绕法曾直接造成窗口不可见和商家放弃授权。
- 商家仍在隔离的京麦登录页自行选择密码/短信/扫码；登录后由原 BrowserAuthJob 导航官方 OAuth、处理当前范围确认并实时核店。日常浏览器 Cookie 不复制，宿主内嵌面板不可操作时不得假称已代点。
- 老店 ready 在只读解析阶段直接返回，不启动嵌入服务。需要新授权才启动；显式 `--no-wait`、自带 HostBrowser/`--browser-config` 保留原高级路径，但宿主必须真正拥有并持续驱动该会话。
- `job` 或 `wait` 返回 `job_lost` 表示原服务任务已经不在，不能继续声称“窗口开着/任务活着”。同店再次 `ensure-shop` 默认恢复；禁止改成手工 OAuth 或跨店新任务。
- 黑色控制台、外部窗口是否可见属于真实宿主/Windows 会话证据，未实机看到窗口前不得汇报“已打开”。前台生命周期修复不代替真实商家可见性验收。

## 审计后的连接返回契约（0.4.7代码候选）

- `--timeout` 是本次登录+OAuth的共用预算，不是每个阶段各加一轮时间。阶段变化输出 `connection-progress` JSON事件（jobId/Profile/阶段/实际通道/剩余预算）；不输出OAuth URL、验证码、Token或页面全文。开页事件只是正在打开，不证明商家可见。
- 超时或用户结束等待，原worker停止并核对原Profile，收尾本任务回调和浏览器上下文后再关嵌入服务。`paused/processRunning=false` 明确没有后台继续；持久浏览器Profile与pending回执保留，下一次同店ensure-shop先核对原结果。收尾未确认时返回阻塞，不能称已关闭或重发。
- 最终 `ready`/`mismatch`/`cancelled`/失败与 `paused` 分开。只有官方完整核店才ready。ID-only新店请求中，可靠工作台店名仅证明登录会话存在，可以衔接本次OAuth；原期望venderId不改、不由DOM猜ID，最终官方ID不匹配仍拒绝登记。
- 同店暂停的callback_unknown优先核验原Profile；未核实则保留暂停，不启动新OAuth。不同店空ID不视为匹配，不串用pending或Profile。
- 以上为代码/离线契约修复；真实WorkBuddy可见窗口、商家登录→OAuth→ready仍须另外获得授权后验证。

## 口述名称与宿主误用（g9jb现场）

- 口述别名未登记、页面官方名不同，返回mismatch时看expectedShopName/actual与needsMerchantAction，问一次是否为同店；未确认不能改证明文件让它通过。以后登记的别名沿用原工具，最终仍以venderinfo核店。
- 内置Playwright直接持有BrowserContext/Page，不以人为打开TCP调试端口为前置。缺少--remote-debugging-port不能直接诊断“控制器看不到”，不能据此改走手工OAuth。可见页面和登录检测的失败应看真实阶段/错误，不读Cookie/History来猜。
- jdo-cli直调必须使用商家隔离环境；不同HOME写出的Profile不是包装器的同一份Profile。禁止cp日常HOME Profile或手改authorization-proof.json作为恢复。修复应复用原待核对回执与正确隔离入口。
- venderinfo的productCount不是商品盘点成功证据；是否有商品以原商品/SKU分页完整性核验为准，不能据0就让商家重新上架。


## 0.4.9：已登录识别、原凭据槽与收尾

- 商家说“登录好了但没反应”时，继续同一条 `ensure-shop` 和 owned BrowserContext。控制器观察同上下文已有工作台页，并使用可靠店名节点；“店铺/客服/首页”等菜单不是店名。登录页不跳转时可低频探测同会话工作台；探测网络超时不刷新商家的登录页、不另建授权任务，仍受原连接预算约束。
- 工作台店名只用来衔接原官方 OAuth。晚出现的 venderId 仍由官方只读核店证明；官方 CLI 本任务的 `:default` 凭据槽只允许在**原 Profile 命名空间、原商家 JDO_HOME**内定位到该数字 ID。要有本任务真实完成/保存/非模拟元数据，并再次核店；原回执缺保存/模拟布尔字段时，只读核对本 Profile 的官方 status 元数据，不猜字段值。首次核店断网前保存原 native 完成标记；网络恢复仅原 jobId、原 Profile 文件、原真实完成记录可恢复槽位并再次核店，没有完成证明的未知授权不重提。不是借全局 default Profile、跨 Profile 复制授权或手改证明的恢复方法。
- 明确 rejected 的失败试连 Profile 保留原文件和审计记录，但不作为可用同店候选；真实不同 venderId 仍按原歧义规则处理，网络失败/未知 Profile 不能随意忽略。
- `ready` 与 `resourceCleanup` 分开：本地浏览器关闭确认无需已经消失的活 contextId；仅已核店、worker 已停止时才可保留 ready 并报告清理待核对。worker 仍活着或回调未知，仍不能声称资源已关闭、后台仍运行或重新发起授权。
- 以上有离线回归和真实 Playwright/Edge 的拦截页面验证，**不是**真实 WorkBuddy 可见窗口、扫码/OAuth、老店免扫码复用的商家验收。
